create view echart_movestatus_view as
select `t`.`move_status` AS `name`, `t`.`move_status` AS `value`, `d`.`target_id` AS `target_id`
from (`db_gdscza`.`t_sample_point` `t`
         join `db_gdscza`.`t_distribute` `d` on ((`t`.`id` = `d`.`sample_point_id`)));

