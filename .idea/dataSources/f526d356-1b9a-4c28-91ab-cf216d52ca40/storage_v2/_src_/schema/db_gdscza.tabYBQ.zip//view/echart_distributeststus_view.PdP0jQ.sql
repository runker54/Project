create view echart_distributeststus_view as
select `d`.`target_is_distribute` AS `name`, `d`.`target_is_distribute` AS `value`, `d`.`target_id` AS `target_id`
from (`db_gdscza`.`t_sample_point` `t`
         join `db_gdscza`.`t_distribute` `d` on ((`t`.`id` = `d`.`sample_point_id`)));

