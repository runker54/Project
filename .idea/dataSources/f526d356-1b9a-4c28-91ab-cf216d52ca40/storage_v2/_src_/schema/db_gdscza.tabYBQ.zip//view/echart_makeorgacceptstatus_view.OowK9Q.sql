create view echart_makeorgacceptstatus_view as
select `t`.`make_org_accept_status` AS `name`, `t`.`make_org_accept_status` AS `value`, `d`.`target_id` AS `target_id`
from (`db_gdscza`.`t_sample_point` `t`
         join `db_gdscza`.`t_distribute` `d` on ((`t`.`id` = `d`.`sample_point_id`)));

