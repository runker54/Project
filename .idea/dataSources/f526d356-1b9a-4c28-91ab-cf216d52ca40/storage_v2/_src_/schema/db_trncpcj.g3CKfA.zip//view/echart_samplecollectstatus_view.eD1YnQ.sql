create definer = root@`%` view echart_samplecollectstatus_view as
select `t`.`sample_collect_status` AS `name`, `t`.`sample_collect_status` AS `value`, `d`.`target_id` AS `target_id`
from (`db_trncpcj`.`t_sample_point` `t`
         join `db_trncpcj`.`t_distribute` `d` on ((`t`.`id` = `d`.`sample_point_id`)));

